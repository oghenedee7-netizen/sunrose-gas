SunRose Gas — Installable Web App

Files:
- index.html — the SunRose Gas staff app
- manifest.webmanifest — install information
- sw.js — offline caching
- icon-192.png / icon-512.png — app icons

To install on an Android phone:
1. Put these files on a website/server using HTTPS.
2. Open the website in Chrome.
3. Choose "Add to Home screen" / "Install app".
4. The app will appear on the phone like an installed app.

Important: A PWA must be served from a web address (HTTPS or localhost) for service-worker installation. Opening index.html directly from a file manager will not provide the full install experience.
